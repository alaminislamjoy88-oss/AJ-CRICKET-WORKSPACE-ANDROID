AJ CRICKET WORKSPACE — Android APK Build

এই ZIP-এ Android Studio/Gradle project source আছে; APK এখনো compile করা হয়নি। এই runtime-এ Android SDK/Gradle নেই, তাই সরাসরি APK বানানো সম্ভব হয়নি।

সহজ Cloud Build (GitHub):
1) ZIP extract করুন।
2) GitHub-এ নতুন repository তৈরি করে এই ফোল্ডারের ভেতরের সব ফাইল upload করুন (ZIP-টি repository-তে upload করে রাখলেই হবে না; extract করা ফাইলগুলো দিতে হবে)।
3) Repository-এর Actions tab খুলুন। “Build AJ Cricket APK” workflow চালু/Run workflow করুন, অথবা main branch-এ push করুন।
4) Build শেষ হলে workflow run-এর Artifacts থেকে “AJ-CRICKET-WORKSPACE-APK” download করুন। ZIP extract করলে app-debug.apk পাবেন।
5) APK ফোনে install করার আগে Android-এ “Install unknown apps” অনুমতি দিতে হতে পারে।

অ্যাপটি HTML-কে Android WebView-তে চালায় এবং WebView DOM/local storage চালু আছে। তাই লোকাল ডেটা সংরক্ষণ সমর্থিত। তবে Google Drive OAuth/backup-কে file:// WebView origin-এ আলাদাভাবে পরীক্ষা করা হয়নি; এটি APK-তে কাজ করবে বলে নিশ্চিত দাবি করা যাচ্ছে না। APK install করার পর আগে test data দিয়ে Save, app বন্ধ/খুলে data, Backup ও Restore পরীক্ষা করবেন।

Package: com.ajcricket.workspace | App name: AJ CRICKET WORKSPACE
